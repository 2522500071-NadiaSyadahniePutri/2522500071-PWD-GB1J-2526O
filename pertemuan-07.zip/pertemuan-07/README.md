# pertemuan-07

NIM : 2522500071<br>
Nama : Nadia Syadahnie Putri<br>

Hari ini, kamis 6 November 2025, Saya mempelajari:
<ol>
<li>copy hello.php, index.php.dll (pertemuan-06)</li>
</ol>