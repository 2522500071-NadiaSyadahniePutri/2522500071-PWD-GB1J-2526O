<?php
    echo "Halo Dunia!";
?>